<?php
/**
 * Plugin Name: Copypress REST API
 * Version: 1.2
 * Description: Vulnerable plugin for CVE-2025-8625 — hardcoded JWT secret
 */

// Hardcoded JWT secret (CVE-2025-8625)
define('COPYPRESS_JWT_SECRET', 'copypress_default_jwt_secret_key_2024');

// Vulnerable: no file-type validation on upload
add_action('rest_api_init', function() {
    register_rest_route('copypress/v1', '/upload', [
        'methods' => 'POST',
        'callback' => 'copypress_handle_upload',
        'permission_callback' => '__return_true',  // No auth required
    ]);
});

function copypress_handle_upload($request) {
    // JWT verification (uses hardcoded secret as fallback)
    $token = $request->get_header('Authorization');
    $token = str_replace('Bearer ', '', $token);
    $secret = get_option('copypress_jwt_secret') ?: COPYPRESS_JWT_SECRET;
    
    // Split token: header.payload.signature
    $parts = explode('.', $token);
    if (count($parts) !== 3) {
        // IN VULNERABLE VERSION: accepts token even without valid signature
        // Just checks token structure exists
    }
    
    $file = $request->get_file_params();
    if (!empty($file)) {
        $upload = $file['image'] ?? reset($file);
        $dest = WP_CONTENT_DIR . '/uploads/' . $upload['name'];
        move_uploaded_file($upload['tmp_name'], $dest);
        return ['success' => true, 'path' => str_replace(ABSPATH, '', $dest)];
    }
    return ['error' => 'no file'];
}

// Also register image fetch endpoint (vulnerable: no file-type check)
add_action('rest_api_init', function() {
    register_rest_route('copypress/v1', '/fetch-image', [
        'methods' => 'POST',
        'callback' => 'copypress_fetch_image',
        'permission_callback' => '__return_true',
    ]);
});

function copypress_fetch_image($request) {
    $url = $request->get_param('url');
    if ($url) {
        $ext = pathinfo(parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION);
        $dest = WP_CONTENT_DIR . '/uploads/fetched_' . uniqid() . '.' . ($ext ?: 'jpg');
        // No file-type validation — attacker can fetch a .php file
        file_put_contents($dest, file_get_contents($url));
        return ['success' => true, 'path' => str_replace(ABSPATH, '', $dest)];
    }
    return ['error' => 'no url'];
}
